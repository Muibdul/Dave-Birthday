'use strict';
import { addUser } from './indexedDb.js';
const loginSignupBtn = document.querySelector('.loging-SiunguBtn');
const loginForm = document.querySelector('.login-form');
const loginUsername = document.querySelector('.username');
const loginPassword = document.querySelector('.password');
const loginBtn = document.querySelector('.login-btn');
// SignUp DOM Elements
const signupLoginBtn = document.querySelector('.signup-LoginBtn');
const signupSection = document.querySelector('.SignUp-Sec');
const loginSection = document.querySelector('.Login-Sec');
const sinupUsername = document.querySelector('.signup-username');
const sinupEmail = document.querySelector('.signup-email');
const sinupPassword = document.querySelector('.signup-password');
const sinupConfPassword = document.querySelector('.signup-conf-password');
const signInBtn = document.querySelector('.Signin-btn');
const singupForm = document.querySelector('.singup-form');
let users = null;

loginSignupBtn.addEventListener('click', () => {
   signupSection.classList.remove('hidden');
   loginSection.classList.add('hidden');
});
signupLoginBtn.addEventListener('click', () => {
   signupSection.classList.add('hidden');
   loginSection.classList.remove('hidden');
});
signInBtn.addEventListener('click', async (e) => {
   e.preventDefault();
   try {
      if (
         sinupEmail.value === '' ||
         sinupUsername.value === '' ||
         sinupPassword.value === '' ||
         sinupConfPassword.value === ''
      ) {
         alert('Please fill all the fields');
         return;
      } else if (sinupPassword.value !== sinupConfPassword.value) {
         alert('Passwords do not match');
         return;
      }
      users = {
         username: sinupUsername.value,
         email: sinupEmail.value,
         password: sinupPassword.value,
         confPassword: sinupConfPassword.value,
      };
      let tx = await addUser('users', 'readwrite');
      let store = tx.objectStore('users');
      store.add(users);
   } catch (error) {
      console.error('Error adding user:', error);
   } finally {
      alert('User registered successfully');
      singupForm.reset();
      signupSection.classList.add('hidden');
      loginSection.classList.remove('hidden');
   }
   console.log(users);
});

loginBtn.addEventListener('click', async (e) => {
   e.preventDefault();
   try {
      if (loginUsername.value === '' || loginPassword.value === '') {
         alert('Please fill all the fields');
         return;
      }
      let tx = await addUser('users', 'readonly');
      let store = tx.objectStore('users');
      let getRequest = store.get(loginUsername.value);
      getRequest.onsuccess = (event) => {
         const user = event.target.result;
         if (user) {
            if (user.password === loginPassword.value) {
               alert('Login successful');
               loginForm.reset();
            } else {
               alert('Incorrect password');
            }
         } else {
            alert('User not found');
         }
      };
      getRequest.onerror = (event) => {
         console.error('Error fetching user:', event.target.errorCode);
      };
   } catch (error) {
      console.error('Error during login:', error);
   }
   console.log('Login attempted');
});
