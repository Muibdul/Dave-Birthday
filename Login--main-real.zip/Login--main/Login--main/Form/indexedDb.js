'use strict';
let db;
const request = indexedDB.open('UserDatabase', 1);
const databse = new Promise((resolve, reject) => {
   request.onsuccess = (event) => {
      db = event.target.result;
      console.log('Database opened successfully');
      resolve(db);
   };
   request.onerror = (event) => {
      reject('Database error: ' + event.target.errorCode);
   };
   request.onupgradeneeded = (event) => {
      db = event.target.result;
      if (!db.objectStoreNames.contains('users')) {
         const objectStore = db.createObjectStore('users', {
            keyPath: 'username',
         });
         objectStore.onsuccess = (event) => {
            console.log('Object store created successfully');
         };
         objectStore.onerror = (event) => {
            console.error('Object store error: ' + event.target.errorCode);
         };
      }
   };
});
export async function addUser(storeName, mode) {
   const db = await databse;
   const transaction = db.transaction(storeName, mode);
   return transaction;
}
